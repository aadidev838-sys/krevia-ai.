import watermarkSrc from "@/assets/watermark.jpg";

let cachedWatermark: HTMLImageElement | null = null;

function loadImage(src: string, crossOrigin = false): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (crossOrigin) img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

async function getWatermark(): Promise<HTMLImageElement> {
  if (cachedWatermark) return cachedWatermark;
  cachedWatermark = await loadImage(watermarkSrc);
  return cachedWatermark;
}

/**
 * Returns a watermarked PNG data URL for the given image source.
 * Falls back to the original src if the canvas is tainted (CORS) or anything fails.
 */
export async function watermarkImage(src: string): Promise<string> {
  try {
    const [base, mark] = await Promise.all([
      loadImage(src, /^https?:/.test(src)),
      getWatermark(),
    ]);
    const canvas = document.createElement("canvas");
    canvas.width = base.naturalWidth;
    canvas.height = base.naturalHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return src;
    ctx.drawImage(base, 0, 0);

    // Watermark = 5% of image width, aspect ratio preserved.
    const ratio = mark.naturalWidth / mark.naturalHeight;
    const wmW = Math.max(24, Math.round(canvas.width * 0.05));
    const wmH = Math.round(wmW / ratio);
    // 1.5% padding from right/bottom edges.
    const padX = Math.round(canvas.width * 0.015);
    const padY = Math.round(canvas.height * 0.015);
    const x = canvas.width - wmW - padX;
    const y = canvas.height - wmH - padY;

    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    // Slight brightness + contrast boost so the mark stays recognizable.
    ctx.filter = "brightness(1.15) contrast(1.2)";
    ctx.drawImage(mark, x, y, wmW, wmH);
    ctx.restore();

    // Preserve quality: PNG for transparency, no lossy compression.
    return canvas.toDataURL("image/png");
  } catch (err) {
    console.warn("watermarkImage failed, returning original", err);
    return src;
  }
}

export async function watermarkFile(file: File): Promise<string> {
  const objectUrl = URL.createObjectURL(file);
  try {
    return await watermarkImage(objectUrl);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
