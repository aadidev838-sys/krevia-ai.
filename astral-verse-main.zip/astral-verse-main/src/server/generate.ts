import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type AspectRatio = "1:1" | "16:9" | "9:16" | "4:5";
type Quality = "fast" | "hd";

type GenerateInput = {
  prompt: string;
  mode: "image" | "video";
  negativePrompt?: string;
  style?: string;
  aspectRatio?: AspectRatio;
  quality?: Quality;
  steps?: number;
  guidance?: number;
  count?: number;
  referenceImage?: string; // data URL or https URL for image-to-image
};

const ASPECT_DIMS: Record<AspectRatio, { w: number; h: number }> = {
  "1:1": { w: 1024, h: 1024 },
  "16:9": { w: 1280, h: 720 },
  "9:16": { w: 720, h: 1280 },
  "4:5": { w: 1024, h: 1280 },
};

const HD_DIMS: Record<AspectRatio, { w: number; h: number }> = {
  "1:1": { w: 1536, h: 1536 },
  "16:9": { w: 1920, h: 1080 },
  "9:16": { w: 1080, h: 1920 },
  "4:5": { w: 1280, h: 1600 },
};

const BLOCKED_MESSAGE =
  "This request cannot be generated. Adult, sexual, and 18+ content are not allowed on this AI platform.";

// Word-boundary patterns covering adult / sexual / 18+ and CSAM-adjacent terms.
// Kept intentionally broad and case-insensitive. Matches whole words so benign
// substrings (e.g. "scunthorpe") are not falsely flagged.
const NSFW_PATTERNS: RegExp[] = [
  /\b(nsfw|nude|nudes|nudity|naked|topless|bottomless|undress(?:ed|ing)?|stripping)\b/i,
  /\b(porn|porno|pornographic|pornography|hentai|rule\s*34|r34|ecchi)\b/i,
  /\b(sex|sexy|sexual|sexually|erotic|erotica|kinky|fetish|bdsm|bondage)\b/i,
  /\b(orgasm|masturbat(?:e|ion|ing)|cum|cumming|jizz|ejaculat(?:e|ion|ing))\b/i,
  /\b(boobs?|breasts?|tits?|nipples?|areolas?|cleavage)\b/i,
  /\b(penis|dick|cock|phallus|testicles?|balls|scrotum)\b/i,
  /\b(vagina|pussy|vulva|clitoris|labia|anus|butthole)\b/i,
  /\b(blowjob|handjob|deepthroat|gangbang|threesome|foursome|orgy)\b/i,
  /\b(lingerie|thong|g[-\s]?string|panties|bikini\s+off|see[-\s]?through)\b/i,
  /\b(18\+|nc[-\s]?17|xxx|x[-\s]?rated|adult\s+(?:content|film|video|scene))\b/i,
  /\b(loli|shota|cp|csam|child\s+(?:porn|sex|nude))\b/i,
  /\b(rape|raping|molest(?:ation|ing)?|incest)\b/i,
];

function isUnsafePrompt(text: string): boolean {
  if (!text) return false;
  return NSFW_PATTERNS.some((re) => re.test(text));
}

function buildPrompt(input: GenerateInput): string {
  const parts: string[] = [input.prompt];
  if (input.referenceImage) {
    parts.unshift(
      "Edit the provided input image. Preserve the original subject, identity, face, pose, composition, and background unless the instruction explicitly changes them. Apply only the requested modification",
    );
  }
  if (input.style && input.style !== "None") parts.push(`Style: ${input.style}`);
  if (input.guidance) parts.push(`prompt adherence ${input.guidance}/20`);
  if (input.steps) parts.push(`detail level ${input.steps}/50`);
  if (input.quality === "hd") parts.push("ultra high resolution, 4k, sharp, intricate details");
  if (input.negativePrompt && input.negativePrompt.trim()) {
    parts.push(`Avoid: ${input.negativePrompt.trim()}`);
  }
  return parts.join(". ");
}

export const generateMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: GenerateInput) => {
    if (!data || typeof data.prompt !== "string" || !data.prompt.trim()) {
      throw new Error("Prompt is required");
    }
    if (data.mode !== "image" && data.mode !== "video") {
      throw new Error("Mode must be 'image' or 'video'");
    }
    const prompt = data.prompt.trim().slice(0, 2000);
    const negativePrompt = (data.negativePrompt?.toString() ?? "").slice(0, 500);
    let referenceImage: string | undefined;
    if (typeof data.referenceImage === "string") {
      const ref = data.referenceImage;
      const isDataImg = /^data:image\/(png|jpe?g|webp|gif);base64,/.test(ref);
      const isHttps = /^https:\/\//.test(ref);
      // Cap at ~6MB which fits a generous base64-encoded ~4.5MB image.
      if ((isDataImg || isHttps) && ref.length <= 6_000_000) {
        referenceImage = ref;
      }
    }
    return {
      prompt,
      mode: data.mode,
      negativePrompt,
      style: data.style ?? "None",
      aspectRatio: (data.aspectRatio ?? "1:1") as AspectRatio,
      quality: (data.quality ?? "fast") as Quality,
      steps: Math.min(50, Math.max(10, Number(data.steps ?? 30))),
      guidance: Math.min(20, Math.max(1, Number(data.guidance ?? 7))),
      count: Math.min(4, Math.max(1, Number(data.count ?? 1))),
      referenceImage,
    };
  })
  .handler(async ({ data }) => {
    // Safety filter — block adult/sexual/18+ requests before hitting any model.
    const combined = `${data.prompt} ${data.negativePrompt ?? ""}`;
    if (isUnsafePrompt(combined)) {
      return { ok: false as const, error: BLOCKED_MESSAGE };
    }

    if (data.mode === "video") {
      return generateVideo(data.prompt);
    }

    const fullPrompt = buildPrompt(data);
    const apiKey = process.env.LOVABLE_API_KEY;

    const tasks = Array.from({ length: data.count }, () =>
      generateOne(fullPrompt, data, apiKey).catch((err) => {
        console.error("generateOne failed:", err);
        return null;
      }),
    );

    const settled = await Promise.all(tasks);
    const urls = settled.filter((u): u is string => typeof u === "string");

    if (urls.length === 0) {
      return {
        ok: false as const,
        error: data.referenceImage
          ? "Image editing is temporarily unavailable. Please try again in a moment."
          : "Image generation is temporarily unavailable. Please try again.",
      };
    }

    return { ok: true as const, mode: "image" as const, urls, prompt: data.prompt };
  });

async function generateOne(
  fullPrompt: string,
  data: { aspectRatio: AspectRatio; quality: Quality; referenceImage?: string },
  apiKey: string | undefined,
): Promise<string | null> {
  if (apiKey) {
    try {
      const userContent: unknown = data.referenceImage
        ? [
            { type: "text", text: fullPrompt },
            { type: "image_url", image_url: { url: data.referenceImage } },
          ]
        : fullPrompt;

      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: data.referenceImage
            ? "google/gemini-3.1-flash-image-preview"
            : "google/gemini-2.5-flash-image",
          messages: [{ role: "user", content: userContent }],
          modalities: ["image", "text"],
        }),
      });

      if (res.ok) {
        const json = await res.json();
        const url: string | undefined = json?.choices?.[0]?.message?.images?.[0]?.image_url?.url;
        if (url) return url;
      } else {
        const text = await res.text();
        console.error("AI gateway error:", res.status, text);
      }
    } catch (err) {
      console.error("primary image gen failed:", err);
    }
  }

  // If the user uploaded a reference image, the generic text-to-image
  // fallback would return an unrelated picture. Better to fail than to
  // silently replace the user's photo with something random.
  if (data.referenceImage) return null;

  return fallbackImage(fullPrompt, data.aspectRatio, data.quality);
}

async function fallbackImage(prompt: string, aspectRatio: AspectRatio, quality: Quality): Promise<string | null> {
  try {
    const dims = quality === "hd" ? HD_DIMS[aspectRatio] : ASPECT_DIMS[aspectRatio];
    const seed = Math.floor(Math.random() * 1_000_000);
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${dims.w}&height=${dims.h}&seed=${seed}&nologo=true&model=flux`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const buf = new Uint8Array(await res.arrayBuffer());
    let binary = "";
    for (let i = 0; i < buf.length; i++) binary += String.fromCharCode(buf[i]);
    const b64 = btoa(binary);
    const contentType = res.headers.get("content-type") || "image/jpeg";
    return `data:${contentType};base64,${b64}`;
  } catch (err) {
    console.error("fallbackImage failed:", err);
    return null;
  }
}

// ---------- Video generation via Replicate ----------
const REPLICATE_MODEL = "bytedance/seedance-1-lite";

async function generateVideo(prompt: string) {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) {
    return { ok: false as const, error: "Video AI is unavailable. Please try again later." };
  }
  try {
    const create = await fetch(
      `https://api.replicate.com/v1/models/${REPLICATE_MODEL}/predictions`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          Prefer: "wait=60",
        },
        body: JSON.stringify({
          input: { prompt, duration: 5, resolution: "480p", aspect_ratio: "16:9" },
        }),
      },
    );

    if (!create.ok) {
      return { ok: false as const, error: "Video AI is unavailable. Please try again later." };
    }

    let prediction = (await create.json()) as ReplicatePrediction;
    const deadline = Date.now() + 3 * 60 * 1000;
    while (
      prediction.status !== "succeeded" &&
      prediction.status !== "failed" &&
      prediction.status !== "canceled" &&
      Date.now() < deadline
    ) {
      await new Promise((r) => setTimeout(r, 2500));
      const pollUrl = prediction.urls?.get;
      if (!pollUrl) break;
      const poll = await fetch(pollUrl, { headers: { Authorization: `Bearer ${token}` } });
      if (!poll.ok) {
        return { ok: false as const, error: "Video AI is unavailable. Please try again later." };
      }
      prediction = (await poll.json()) as ReplicatePrediction;
    }

    if (prediction.status !== "succeeded") {
      return { ok: false as const, error: prediction.error ?? "Video generation failed. Try a different prompt." };
    }

    const url = extractVideoUrl(prediction.output);
    if (!url) {
      return { ok: false as const, error: "No video returned. Try a different prompt." };
    }
    return { ok: true as const, mode: "video" as const, url, prompt };
  } catch (err) {
    console.error("generateVideo failed:", err);
    return { ok: false as const, error: "Video generation failed. Please try again." };
  }
}

type ReplicatePrediction = {
  id: string;
  status: "starting" | "processing" | "succeeded" | "failed" | "canceled";
  output?: string | string[] | null;
  error?: string | null;
  urls?: { get?: string; cancel?: string };
};

function extractVideoUrl(output: ReplicatePrediction["output"]): string | null {
  if (!output) return null;
  if (typeof output === "string") return output;
  if (Array.isArray(output) && output.length > 0 && typeof output[0] === "string") {
    return output[output.length - 1];
  }
  return null;
}
