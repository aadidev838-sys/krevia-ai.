import { Github, Twitter, Instagram, Youtube } from "lucide-react";
import { Link } from "@tanstack/react-router";
import logo from "@/assets/krevia-logo.png";

export function Footer() {
  const socials = [
    { Icon: Twitter, href: "#" },
    { Icon: Github, href: "#" },
    { Icon: Instagram, href: "https://www.instagram.com/aadidev_x_?igsh=cnBlempnczB3Nmp6" },
    { Icon: Youtube, href: "#" },
  ];

  return (
    <footer className="relative z-10 mt-32 border-t border-white/5 px-4 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 md:flex-row">
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center gap-2 md:justify-start">
            <img
              src={logo}
              alt="krevia-ai logo"
              width={28}
              height={28}
              loading="lazy"
              className="h-7 w-7 object-contain invert"
            />
            <p className="font-display text-lg font-bold">krevia-ai</p>
          </div>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} — Crafted from light & shadow.</p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm">
          <Link
            to="/terms"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            Terms &amp; Conditions
          </Link>
          <Link
            to="/privacy"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            Privacy Policy
          </Link>
        </div>

        <div className="flex items-center gap-3">
          {socials.map(({ Icon, href }, i) => (
            <a
              key={i}
              href={href}
              {...(href.startsWith("http") ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              aria-label={Icon.displayName || "social link"}
              className="glass jump-hover group relative flex h-10 w-10 items-center justify-center rounded-full transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 hover:shadow-[0_0_20px_rgba(255,255,255,0.35)]"
            >
              <Icon className="h-4 w-4 transition-transform duration-300 group-hover:scale-125" />
            </a>
          ))}
        </div>
      </div>

      <div className="mt-10 flex justify-center">
        <p className="font-display text-base md:text-lg font-bold tracking-wide text-white/80">
          Developed by Aadidev
        </p>
      </div>
    </footer>
  );
}
