import { useState } from "react";
import { MessageSquare, X, Send, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export function FeedbackButton() {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const close = () => {
    if (sending) return;
    setOpen(false);
    setTimeout(() => {
      setSent(false);
      setMessage("");
      setEmail("");
    }, 250);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = message.trim();
    if (trimmed.length < 2) {
      toast.error("Please write a short message before sending.");
      return;
    }
    setSending(true);
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed, email: email.trim() || undefined }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || "Failed to send feedback.");
      setSent(true);
      toast.success("Feedback sent. Thank you!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      {/* Floating button */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Send feedback"
        data-action="open-feedback"
        className="fixed bottom-5 right-5 z-[60] group flex items-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-medium text-primary-foreground shadow-[0_8px_30px_-6px_oklch(0.7_0.18_280/0.55)] transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_40px_-6px_oklch(0.7_0.18_280/0.7)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:bottom-6 sm:right-6"
      >
        <MessageSquare className="h-4 w-4" />
        <span className="hidden sm:inline">Feedback</span>
        <span className="absolute inset-0 -z-10 rounded-full bg-primary/40 blur-xl opacity-0 transition-opacity group-hover:opacity-100" />
      </button>

      {/* Modal */}
      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Send feedback"
        >
          <button
            type="button"
            aria-label="Close"
            onClick={close}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in-0 duration-200"
          />
          <div className="relative w-full max-w-md glass rounded-t-3xl sm:rounded-3xl border border-white/10 p-6 shadow-2xl animate-in slide-in-from-bottom-4 sm:zoom-in-95 sm:slide-in-from-bottom-0 fade-in-0 duration-300">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display text-xl font-bold">Share your feedback</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  Tell us what you love, what's broken, or what's missing.
                </p>
              </div>
              <button
                onClick={close}
                disabled={sending}
                aria-label="Close"
                className="rounded-full p-1.5 text-muted-foreground hover:bg-white/10 hover:text-foreground transition disabled:opacity-50"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {sent ? (
              <div className="flex flex-col items-center py-10 text-center animate-in fade-in-0 zoom-in-95 duration-300">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
                  <CheckCircle2 className="h-7 w-7 text-primary" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold">Feedback sent</h3>
                <p className="mt-1 max-w-xs text-sm text-muted-foreground">
                  Thank you — your message landed safely. We read every note.
                </p>
                <button
                  onClick={close}
                  className="mt-6 rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground glow-hover"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="mt-5 space-y-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email (optional)"
                  autoComplete="email"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition"
                />
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Write your feedback..."
                  rows={5}
                  required
                  maxLength={5000}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition"
                />
                <div className="flex items-center justify-between gap-3 pt-1">
                  <span className="text-[11px] text-muted-foreground">
                    {message.length}/5000
                  </span>
                  <button
                    type="submit"
                    disabled={sending || message.trim().length < 2}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground glow-hover disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {sending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" /> Sending
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" /> Send
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}
