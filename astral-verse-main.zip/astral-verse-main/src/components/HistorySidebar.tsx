import { useEffect, useState } from "react";
import { Menu, RefreshCcw, Trash2, Download, X, ImageOff } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";

type HistoryItem = {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  ts: number;
  favorite?: boolean;
};

const HISTORY_KEY = "krevia.history.v1";
const HISTORY_EVENT = "krevia:history-updated";

function readHistory(): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeHistory(items: HistoryItem[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
    window.dispatchEvent(new CustomEvent(HISTORY_EVENT));
  } catch {
    /* noop */
  }
}

async function downloadImage(url: string, filename: string) {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch {
    // last-resort: open in new tab
    window.open(url, "_blank", "noopener,noreferrer");
  }
}

export function HistorySidebar() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    const sync = () => setItems(readHistory());
    sync();
    window.addEventListener(HISTORY_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(HISTORY_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  // Refresh on open in case localStorage changed in same tab without event.
  useEffect(() => {
    if (open) setItems(readHistory());
  }, [open]);

  const reload = (item: HistoryItem) => {
    window.dispatchEvent(
      new CustomEvent("krevia:reload-prompt", { detail: item }),
    );
    setOpen(false);
    requestAnimationFrame(() => {
      document
        .getElementById("generator-card")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  const remove = (id: string) => {
    const next = items.filter((i) => i.id !== id);
    setItems(next);
    writeHistory(next);
  };

  const clearAll = () => {
    setItems([]);
    writeHistory([]);
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          aria-label="Open history"
          className="fixed left-4 top-4 z-[60] inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-black/60 text-foreground backdrop-blur-xl transition hover:bg-white/10 md:left-6 md:top-6"
        >
          <Menu className="h-5 w-5" />
        </button>
      </SheetTrigger>
      <SheetContent
        side="left"
        className="w-[88vw] max-w-sm border-r border-white/10 bg-black/85 p-0 text-foreground backdrop-blur-2xl"
      >
        <SheetHeader className="border-b border-white/10 px-5 py-4 text-left">
          <SheetTitle className="font-display text-lg">History</SheetTitle>
          <SheetDescription className="text-xs text-muted-foreground">
            Your recent generations. Reload a prompt or remove items.
          </SheetDescription>
          {items.length > 0 && (
            <button
              onClick={clearAll}
              className="mt-2 inline-flex w-fit items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
            >
              <Trash2 className="h-3 w-3" /> Clear all
            </button>
          )}
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-7.5rem)]">
          {items.length === 0 ? (
            <div className="flex h-64 flex-col items-center justify-center gap-2 px-6 text-center text-muted-foreground">
              <ImageOff className="h-8 w-8 opacity-50" />
              <p className="text-sm">No generations yet.</p>
              <p className="text-xs opacity-70">
                Create something — your history will live here.
              </p>
            </div>
          ) : (
            <ul className="space-y-2 p-3">
              {items.map((item) => (
                <li
                  key={item.id}
                  className="group flex gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-2 transition hover:bg-white/[0.06]"
                >
                  <button
                    onClick={() => reload(item)}
                    className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg border border-white/10 bg-black/40"
                    aria-label="Reload prompt"
                  >
                    <img
                      src={item.url}
                      alt={item.prompt}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </button>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <p className="line-clamp-2 text-xs leading-snug text-foreground">
                      {item.prompt}
                    </p>
                    <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                      {item.style !== "None" ? `${item.style} · ` : ""}
                      {item.aspectRatio}
                    </p>
                    <div className="mt-auto flex items-center gap-1 pt-1.5">
                      <button
                        onClick={() => reload(item)}
                        className="inline-flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[10px] font-semibold text-black transition hover:bg-white"
                      >
                        <RefreshCcw className="h-2.5 w-2.5" /> Reload
                      </button>
                      <button
                        onClick={() =>
                          downloadImage(item.url, `krevia-${item.id}.png`)
                        }
                        className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
                        aria-label="Download"
                      >
                        <Download className="h-2.5 w-2.5" />
                      </button>
                      <button
                        onClick={() => remove(item.id)}
                        className="ml-auto inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-muted-foreground transition hover:bg-red-500/80 hover:text-white"
                        aria-label="Delete"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
