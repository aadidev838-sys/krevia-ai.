import { Link, useNavigate } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth";
import logo from "@/assets/krevia-logo.png";

export function Navbar() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const links = [
    { to: "/", label: "Create" },
    { to: "/dashboard", label: "Dashboard" },
    { to: "/pricing", label: "Pricing" },
  ] as const;

  const handleLogout = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-4 pl-16 md:pl-4">
      <nav className="glass flex w-full max-w-6xl items-center justify-between rounded-full px-5 py-3">
        <Link to="/" className="flex items-center gap-2 group">
          <img
            src={logo}
            alt="krevia-ai logo"
            width={32}
            height={32}
            className="h-8 w-8 object-contain invert transition-transform duration-500 group-hover:scale-110"
          />
          <span className="font-display text-lg font-bold tracking-tight">krevia-ai</span>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="jump-hover rounded-full px-4 py-2 text-sm text-muted-foreground transition-all hover:text-foreground hover:bg-white/5"
              activeProps={{ className: "rounded-full px-4 py-2 text-sm text-foreground bg-white/10" }}
              activeOptions={{ exact: true }}
            >
              {l.label}
            </Link>
          ))}
        </div>

        {user ? (
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline max-w-[160px] truncate rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-muted-foreground">
              {user.email}
            </span>
            <button
              onClick={handleLogout}
              className="jump-hover flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-2 text-sm font-medium hover:bg-white/5 transition"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        ) : (
          <Link
            to="/login"
            className="jump-hover rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground glow-hover"
          >
            Login
          </Link>
        )}
      </nav>
    </header>
  );
}
