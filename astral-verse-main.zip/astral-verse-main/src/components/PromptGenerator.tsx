import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Image as ImageIcon,
  Video,
  Sparkles,
  Wand2,
  Download,
  Copy,
  Check,
  AlertTriangle,
  Upload,
  X,
  Shuffle,
  RefreshCw,
  Heart,
  Trash2,
  Maximize2,
  Share2,
  Settings2,
  Zap,
  Crown,
  Lightbulb,
  Layers,
  ArrowUpCircle,
  ChevronDown,
} from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { generateMedia } from "@/server/generate";
import { watermarkImage, watermarkFile } from "@/lib/watermark";

type Mode = "image" | "video";
type AspectRatio = "1:1" | "16:9" | "9:16" | "4:5";
type Quality = "fast" | "hd";

const STYLES = [
  "None",
  "Realistic",
  "Anime",
  "3D Render",
  "Cartoon",
  "Cinematic",
  "Digital Art",
  "Portrait",
  "Fantasy",
];

const ASPECT_RATIOS: AspectRatio[] = ["1:1", "16:9", "9:16", "4:5"];

const TRENDING_PROMPTS = [
  "A lone astronaut on a glass cliff overlooking a black hole, cinematic",
  "Neon-lit cyberpunk alley with rain reflections, ultra detailed",
  "Mythical phoenix rising from molten gold, dramatic lighting",
  "Portrait of a queen made of liquid mercury, hyperreal",
  "Tiny isometric island floating in pastel clouds, 3D render",
  "Origami fox in a moonlit bamboo forest, depth of field",
  "Cosmic jellyfish drifting through a nebula, ethereal",
  "Brutalist cathedral on Mars at sunset, photorealistic",
];

const PLACEHOLDERS = [
  "A lone astronaut on a glass cliff overlooking a black hole...",
  "Slow-motion ink dropping into water, monochrome, ultra detailed...",
  "An ancient library inside a giant tree, magical light beams...",
  "Cyberpunk samurai in neon Tokyo rain, cinematic close-up...",
];

type HistoryItem = {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: AspectRatio;
  ts: number;
  favorite?: boolean;
};

const HISTORY_KEY = "krevia.history.v1";
const MAX_HISTORY = 60;
const HISTORY_EVENT = "krevia:history-updated";
const RELOAD_EVENT = "krevia:reload-prompt";
const PENDING_PROMPT_KEY = "krevia.pendingPrompt.v1";

type PendingPrompt = {
  prompt: string;
  negativePrompt?: string;
  style?: string;
  aspectRatio?: AspectRatio;
  quality?: Quality;
  count?: 1 | 2 | 3 | 4;
  mode?: Mode;
  autoRun?: boolean;
};

function loadHistory(): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function saveHistory(items: HistoryItem[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, MAX_HISTORY)));
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent(HISTORY_EVENT));
    }
  } catch {
    /* noop */
  }
}

async function downloadAsset(url: string, filename: string) {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch {
    window.open(url, "_blank", "noopener,noreferrer");
  }
}

export function PromptGenerator() {
  const [mode, setMode] = useState<Mode>("image");
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("");
  const [style, setStyle] = useState<string>("None");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1");
  const [quality, setQuality] = useState<Quality>("fast");
  const [steps, setSteps] = useState(30);
  const [guidance, setGuidance] = useState(7);
  const [count, setCount] = useState<1 | 2 | 3 | 4>(1);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<HistoryItem[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [fullscreen, setFullscreen] = useState<HistoryItem | null>(null);
  const [placeholder] = useState(
    () => PLACEHOLDERS[Math.floor(Math.random() * PLACEHOLDERS.length)],
  );

  const fileInputRef = useRef<HTMLInputElement>(null);
  const generate = useServerFn(generateMedia);
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    setHistory(loadHistory());
  }, []);

  // Listen for sidebar "reload prompt" requests.
  useEffect(() => {
    const onReload = (e: Event) => {
      const detail = (e as CustomEvent<HistoryItem>).detail;
      if (!detail) return;
      setPrompt(detail.prompt);
      if (detail.style) setStyle(detail.style);
      if (detail.aspectRatio) setAspectRatio(detail.aspectRatio as AspectRatio);
    };
    const onHistoryUpdated = () => setHistory(loadHistory());
    window.addEventListener(RELOAD_EVENT, onReload as EventListener);
    window.addEventListener(HISTORY_EVENT, onHistoryUpdated);
    return () => {
      window.removeEventListener(RELOAD_EVENT, onReload as EventListener);
      window.removeEventListener(HISTORY_EVENT, onHistoryUpdated);
    };
  }, []);

  // Restore a pending prompt that was saved before redirecting to login.
  // Runs once auth has resolved; if the user is signed in we auto-generate
  // so they don't have to click Generate again.
  useEffect(() => {
    if (authLoading) return;
    if (typeof window === "undefined") return;
    const raw = sessionStorage.getItem(PENDING_PROMPT_KEY);
    if (!raw) return;
    try {
      const pending = JSON.parse(raw) as PendingPrompt;
      if (pending.prompt) setPrompt(pending.prompt);
      if (pending.negativePrompt !== undefined) setNegativePrompt(pending.negativePrompt);
      if (pending.style) setStyle(pending.style);
      if (pending.aspectRatio) setAspectRatio(pending.aspectRatio);
      if (pending.quality) setQuality(pending.quality);
      if (pending.count) setCount(pending.count);
      if (pending.mode) setMode(pending.mode);
      sessionStorage.removeItem(PENDING_PROMPT_KEY);
      if (user && pending.autoRun && pending.prompt.trim()) {
        // Slight delay so state updates flush before generate.
        setTimeout(() => {
          runGenerate({ promptOverride: pending.prompt });
        }, 50);
      }
    } catch {
      sessionStorage.removeItem(PENDING_PROMPT_KEY);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  const trending = useMemo(() => TRENDING_PROMPTS.slice(0, 4), []);

  const runGenerate = async (opts?: {
    promptOverride?: string;
    enhance?: "upscale" | "sharpen" | "deblur" | "face";
  }) => {
    const finalPromptBase = (opts?.promptOverride ?? prompt).trim();
    if (!finalPromptBase || loading) return;
    if (!user) {
      // Preserve the in-progress prompt + settings so we can restore them
      // and auto-continue after the Google login redirect.
      try {
        const pending: PendingPrompt = {
          prompt: finalPromptBase,
          negativePrompt,
          style,
          aspectRatio,
          quality,
          count,
          mode,
          autoRun: true,
        };
        sessionStorage.setItem(PENDING_PROMPT_KEY, JSON.stringify(pending));
      } catch {
        /* noop */
      }
      navigate({ to: "/login", search: { redirect: "/" } });
      return;
    }
    setLoading(true);
    setError(null);

    let enhancedPrompt = finalPromptBase;
    let forceQuality: Quality = quality;
    if (opts?.enhance === "upscale") {
      enhancedPrompt += ", upscaled, ultra high resolution, extreme detail";
      forceQuality = "hd";
    } else if (opts?.enhance === "sharpen") {
      enhancedPrompt += ", razor-sharp focus, crisp edges, fine textures";
    } else if (opts?.enhance === "deblur") {
      enhancedPrompt += ", tack sharp, no blur, perfect focus";
    } else if (opts?.enhance === "face") {
      enhancedPrompt += ", flawless face details, symmetrical features, skin micro-texture, studio lighting";
    }

    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      if (!token) {
        setError("Your session expired. Please sign in again.");
        setLoading(false);
        return;
      }
      const res = await generate({
        data: {
          prompt: enhancedPrompt,
          mode,
          negativePrompt,
          style,
          aspectRatio,
          quality: forceQuality,
          steps,
          guidance,
          count,
          referenceImage: referenceImage ?? undefined,
        },
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      if (res.mode === "video") {
        const item: HistoryItem = {
          id: `v-${Date.now()}`,
          url: res.url,
          prompt: enhancedPrompt,
          style,
          aspectRatio: "16:9",
          ts: Date.now(),
        };
        setResults([item]);
        const next = [item, ...history].slice(0, MAX_HISTORY);
        setHistory(next);
        saveHistory(next);
      } else {
        const marked = await Promise.all(
          res.urls.map(async (u, i) => ({
            id: `i-${Date.now()}-${i}`,
            url: await watermarkImage(u),
            prompt: enhancedPrompt,
            style,
            aspectRatio,
            ts: Date.now(),
          })),
        );
        setResults(marked);
        const next = [...marked, ...history].slice(0, MAX_HISTORY);
        setHistory(next);
        saveHistory(next);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async (text?: string) => {
    await navigator.clipboard?.writeText(text ?? prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleReferenceFile = async (files: FileList | null) => {
    if (!files || !files[0]) return;
    const file = files[0];
    if (!file.type.startsWith("image/")) return;
    const watermarked = await watermarkFile(file);
    setReferenceImage(watermarked);
  };

  const randomPrompt = () => {
    const p = TRENDING_PROMPTS[Math.floor(Math.random() * TRENDING_PROMPTS.length)];
    setPrompt(p);
  };

  const toggleFavorite = (id: string) => {
    setHistory((prev) => {
      const next = prev.map((h) => (h.id === id ? { ...h, favorite: !h.favorite } : h));
      saveHistory(next);
      return next;
    });
    setResults((prev) => prev.map((h) => (h.id === id ? { ...h, favorite: !h.favorite } : h)));
  };

  const deleteItem = (id: string) => {
    setHistory((prev) => {
      const next = prev.filter((h) => h.id !== id);
      saveHistory(next);
      return next;
    });
    setResults((prev) => prev.filter((h) => h.id !== id));
  };

  const reloadPrompt = (item: HistoryItem) => {
    setPrompt(item.prompt);
    setStyle(item.style);
    setAspectRatio(item.aspectRatio);
    document.getElementById("generator-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const shareItem = async (item: HistoryItem) => {
    try {
      if (navigator.share) {
        await navigator.share({ title: "krevia-ai creation", text: item.prompt, url: item.url });
      } else {
        await navigator.clipboard.writeText(item.url);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }
    } catch {
      /* user cancelled */
    }
  };

  const isVideo = mode === "video";

  return (
    <div id="generator-card" className="w-full max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
        className="glass-strong neon-border relative w-full rounded-3xl p-5 md:p-7"
      >
        {/* Mode toggle */}
        <div className="flex items-center justify-between gap-3 mb-5">
          <div className="flex w-fit items-center gap-1 rounded-full border border-white/10 bg-black/40 p-1">
            {(["image", "video"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className="relative rounded-full px-4 py-1.5 text-xs font-medium transition-colors"
              >
                {mode === m && (
                  <motion.div
                    layoutId="mode-pill"
                    className="absolute inset-0 rounded-full bg-white"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span
                  className={`relative z-10 flex items-center gap-1.5 ${mode === m ? "text-black" : "text-muted-foreground"}`}
                >
                  {m === "image" ? <ImageIcon className="h-3.5 w-3.5" /> : <Video className="h-3.5 w-3.5" />}
                  {m === "image" ? "Image" : "Video"}
                </span>
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowAdvanced((s) => !s)}
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground hover:bg-white/10 transition"
          >
            <Settings2 className="h-3.5 w-3.5" />
            Advanced
            <ChevronDown className={`h-3 w-3 transition-transform ${showAdvanced ? "rotate-180" : ""}`} />
          </button>
        </div>

        {/* Prompt input + upload-aligned */}
        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={placeholder}
            rows={3}
            className="w-full resize-none rounded-2xl border border-white/10 bg-black/40 p-4 pr-12 text-sm md:text-base placeholder:text-muted-foreground/50 focus:border-white/30 focus:outline-none focus:ring-2 focus:ring-white/10 transition"
          />
          <Sparkles className="pointer-events-none absolute right-4 top-4 h-4 w-4 text-white/30" />
        </div>

        {/* Quick prompt suggestions */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
            <Lightbulb className="h-3 w-3" /> Try
          </span>
          {trending.map((t) => (
            <button
              key={t}
              onClick={() => setPrompt(t)}
              className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition"
            >
              {t.length > 38 ? t.slice(0, 36) + "…" : t}
            </button>
          ))}
          <button
            onClick={randomPrompt}
            className="ml-auto inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition"
          >
            <Shuffle className="h-3 w-3" /> Random
          </button>
        </div>

        {/* Style + Aspect + Quality + Count */}
        <div className="mt-5 grid gap-4">
          <div>
            <label className="mb-1.5 block text-[10px] uppercase tracking-wider text-muted-foreground">Style</label>
            <div className="flex flex-wrap gap-1.5">
              {STYLES.map((s) => (
                <button
                  key={s}
                  onClick={() => setStyle(s)}
                  className={`rounded-full px-3 py-1.5 text-xs transition border ${
                    style === s
                      ? "border-white/30 bg-white text-black"
                      : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/10 hover:text-foreground"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-[10px] uppercase tracking-wider text-muted-foreground">Aspect ratio</label>
              <div className="flex gap-1.5">
                {ASPECT_RATIOS.map((a) => (
                  <button
                    key={a}
                    onClick={() => setAspectRatio(a)}
                    className={`flex-1 rounded-lg px-2 py-2 text-xs transition border ${
                      aspectRatio === a
                        ? "border-white/30 bg-white/10 text-foreground"
                        : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/5"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-[10px] uppercase tracking-wider text-muted-foreground">Quality</label>
              <div className="flex gap-1.5">
                <button
                  onClick={() => setQuality("fast")}
                  className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs transition border ${
                    quality === "fast"
                      ? "border-white/30 bg-white/10 text-foreground"
                      : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/5"
                  }`}
                >
                  <Zap className="h-3.5 w-3.5" /> Fast
                </button>
                <button
                  onClick={() => setQuality("hd")}
                  className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs transition border ${
                    quality === "hd"
                      ? "border-white/30 bg-white/10 text-foreground"
                      : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/5"
                  }`}
                >
                  <Crown className="h-3.5 w-3.5" /> HD
                </button>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-[10px] uppercase tracking-wider text-muted-foreground">Images</label>
              <div className="flex gap-1.5">
                {([1, 2, 3, 4] as const).map((n) => (
                  <button
                    key={n}
                    onClick={() => setCount(n)}
                    className={`flex-1 rounded-lg py-2 text-xs transition border ${
                      count === n
                        ? "border-white/30 bg-white/10 text-foreground"
                        : "border-white/10 bg-white/[0.03] text-muted-foreground hover:bg-white/5"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Advanced */}
        <AnimatePresence>
          {showAdvanced && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 overflow-hidden"
            >
              <div className="rounded-2xl border border-white/10 bg-black/30 p-4 space-y-4">
                <div>
                  <label className="mb-1.5 block text-[10px] uppercase tracking-wider text-muted-foreground">Negative prompt</label>
                  <input
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    placeholder="blurry, low-quality, watermark, extra fingers..."
                    className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-xs placeholder:text-muted-foreground/50 focus:border-white/30 focus:outline-none"
                  />
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <SliderRow label="Steps / creativity" value={steps} min={10} max={50} onChange={setSteps} />
                  <SliderRow label="Guidance scale" value={guidance} min={1} max={20} onChange={setGuidance} />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Reference image (image-to-image) */}
        <AnimatePresence>
          {referenceImage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 overflow-hidden"
            >
              <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <div className="relative h-16 w-16 overflow-hidden rounded-lg border border-white/10">
                  <img src={referenceImage} alt="reference" className="h-full w-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium">Reference image attached</p>
                  <p className="text-[10px] text-muted-foreground">Generations will edit / transform this image.</p>
                </div>
                <button
                  onClick={() => setReferenceImage(null)}
                  className="rounded-full border border-white/10 bg-white/5 p-1.5 text-muted-foreground hover:bg-white/10 hover:text-foreground transition"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Actions row */}
        <div className="mt-5 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                handleReferenceFile(e.target.files);
                e.target.value = "";
              }}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              data-action="upload-photo"
              className="ripple flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
            >
              <Upload className="h-3.5 w-3.5" />
              Upload photo
            </button>
            <button
              onClick={() => handleCopy()}
              disabled={!prompt.trim()}
              className="ripple flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-muted-foreground transition hover:bg-white/10 hover:text-foreground disabled:opacity-40"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copied" : "Copy prompt"}
            </button>
            {results.length > 0 && (
              <button
                onClick={() => runGenerate()}
                disabled={loading}
                className="ripple flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-muted-foreground transition hover:bg-white/10 hover:text-foreground disabled:opacity-40"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Regenerate
              </button>
            )}
          </div>
          <button
            onClick={() => runGenerate()}
            disabled={loading || !prompt.trim()}
            className="ripple btn-neon group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-7 py-3 text-sm font-semibold disabled:opacity-60"
          >
            {loading ? (
              <>
                <LiquidSpinner />
                <span>Conjuring…</span>
              </>
            ) : (
              <>
                <Wand2 className="h-4 w-4" />
                <span>Generate</span>
              </>
            )}
          </button>
        </div>

        {/* Error */}
        <AnimatePresence>
          {error && !loading && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-4 flex items-start gap-2 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-muted-foreground"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0 text-white/70" />
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading skeletons */}
        <AnimatePresence>
          {loading && (
            <motion.div
              key="loading"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-6 overflow-hidden"
            >
              <div className={`grid gap-3 ${count > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                {Array.from({ length: count }).map((_, i) => (
                  <div
                    key={i}
                    className="skeleton-shimmer relative overflow-hidden rounded-2xl border border-white/10"
                    style={{ aspectRatio: aspectRatio.replace(":", " / ") }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <LiquidSpinner large />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-white/10">
                <div className="h-full w-1/3 animate-pulse bg-gradient-to-r from-transparent via-white to-transparent" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results */}
        <AnimatePresence>
          {!loading && results.length > 0 && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-6"
            >
              <div className={`grid gap-3 ${results.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                {results.map((r) => (
                  <ResultCard
                    key={r.id}
                    item={r}
                    isVideo={isVideo}
                    onCopy={() => handleCopy(r.prompt)}
                    onFavorite={() => toggleFavorite(r.id)}
                    onDelete={() => deleteItem(r.id)}
                    onFullscreen={() => setFullscreen(r)}
                    onShare={() => shareItem(r)}
                    onRegenSimilar={() => runGenerate({ promptOverride: r.prompt })}
                    onUpscale={() => runGenerate({ promptOverride: r.prompt, enhance: "upscale" })}
                    onSharpen={() => runGenerate({ promptOverride: r.prompt, enhance: "sharpen" })}
                    onDeblur={() => runGenerate({ promptOverride: r.prompt, enhance: "deblur" })}
                    onFace={() => runGenerate({ promptOverride: r.prompt, enhance: "face" })}
                    onUseAsReference={() => setReferenceImage(r.url)}
                    onDownload={() =>
                      downloadAsset(r.url, `krevia-${r.id}.${isVideo ? "mp4" : "png"}`)
                    }
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* History */}
      {history.length > 0 && (
        <section className="mt-10">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Your history</p>
              <h3 className="font-display text-2xl font-bold text-gradient">Recently generated</h3>
            </div>
            <button
              onClick={() => {
                setHistory([]);
                saveHistory([]);
              }}
              className="text-[11px] text-muted-foreground hover:text-foreground transition"
            >
              Clear all
            </button>
          </div>
          <div className="masonry">
            {history.map((h) => (
              <motion.div
                key={h.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass group relative overflow-hidden rounded-2xl"
              >
                <img
                  src={h.url}
                  alt={h.prompt}
                  loading="lazy"
                  className="block w-full transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/0 to-black/0 opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="absolute bottom-2 left-2 right-2 flex flex-wrap items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => reloadPrompt(h)}
                    className="rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-semibold text-black hover:bg-white"
                  >
                    Reload
                  </button>
                  <button
                    onClick={() => downloadAsset(h.url, `krevia-${h.id}.png`)}
                    className="inline-flex items-center gap-1 rounded-full bg-black/60 px-2.5 py-1 text-[10px] text-white backdrop-blur hover:bg-black/80"
                    aria-label="Download"
                  >
                    <Download className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => toggleFavorite(h.id)}
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] backdrop-blur ${
                      h.favorite ? "bg-white text-black" : "bg-black/60 text-white hover:bg-black/80"
                    }`}
                  >
                    <Heart className={`h-3 w-3 ${h.favorite ? "fill-current" : ""}`} />
                  </button>
                  <button
                    onClick={() => setFullscreen(h)}
                    className="inline-flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[10px] text-white backdrop-blur hover:bg-black/80 ml-auto"
                  >
                    <Maximize2 className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => deleteItem(h.id)}
                    className="inline-flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[10px] text-white backdrop-blur hover:bg-red-500/80"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Fullscreen lightbox */}
      <AnimatePresence>
        {fullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setFullscreen(null)}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[92vh] max-w-[92vw]"
            >
              <img src={fullscreen.url} alt={fullscreen.prompt} className="max-h-[88vh] max-w-[92vw] rounded-2xl object-contain" />
              <button
                onClick={() => setFullscreen(null)}
                className="absolute -top-3 -right-3 rounded-full bg-white p-2 text-black shadow-lg hover:scale-110 transition"
              >
                <X className="h-4 w-4" />
              </button>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <button
                  onClick={() => downloadAsset(fullscreen.url, `krevia-${fullscreen.id}.png`)}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-black"
                >
                  <Download className="h-3.5 w-3.5" /> HD Download
                </button>
                <button
                  onClick={() => shareItem(fullscreen)}
                  className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs text-white"
                >
                  <Share2 className="h-3.5 w-3.5" /> Share
                </button>
                <p className="ml-auto max-w-md truncate text-xs text-white/70">{fullscreen.prompt}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className="text-xs font-mono text-foreground">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-white"
      />
    </div>
  );
}

function ResultCard({
  item,
  isVideo,
  onCopy,
  onFavorite,
  onDelete,
  onFullscreen,
  onShare,
  onRegenSimilar,
  onUpscale,
  onSharpen,
  onDeblur,
  onFace,
  onUseAsReference,
  onDownload,
}: {
  item: HistoryItem;
  isVideo: boolean;
  onCopy: () => void;
  onFavorite: () => void;
  onDelete: () => void;
  onFullscreen: () => void;
  onShare: () => void;
  onRegenSimilar: () => void;
  onUpscale: () => void;
  onSharpen: () => void;
  onDeblur: () => void;
  onFace: () => void;
  onUseAsReference: () => void;
  onDownload: () => void;
}) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass group relative overflow-hidden rounded-2xl"
    >
      {isVideo ? (
        <video src={item.url} controls autoPlay loop playsInline className="block w-full" />
      ) : (
        <img src={item.url} alt={item.prompt} loading="lazy" className="block w-full transition-transform duration-700 group-hover:scale-[1.02]" />
      )}
      <div className="space-y-2 p-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={onDownload}
            className="ripple inline-flex items-center gap-1 rounded-full bg-white px-2.5 py-1 text-[11px] font-semibold text-black hover:shadow-[0_0_24px_rgba(255,255,255,0.4)] transition"
          >
            <Download className="h-3 w-3" /> HD
          </button>
          <button onClick={onShare} className="ripple inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
            <Share2 className="h-3 w-3" />
          </button>
          <button onClick={onCopy} className="ripple inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
            <Copy className="h-3 w-3" />
          </button>
          <button onClick={onRegenSimilar} className="ripple inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
            <RefreshCw className="h-3 w-3" /> Similar
          </button>
          <button
            onClick={onFavorite}
            className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] transition ${
              item.favorite ? "bg-white text-black" : "border border-white/10 bg-white/5 text-muted-foreground hover:bg-white/10"
            }`}
          >
            <Heart className={`h-3 w-3 ${item.favorite ? "fill-current" : ""}`} />
          </button>
          <button onClick={onFullscreen} className="ripple inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
            <Maximize2 className="h-3 w-3" />
          </button>
          <button onClick={onDelete} className="ripple inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-muted-foreground hover:bg-red-500/80 hover:text-white transition ml-auto">
            <Trash2 className="h-3 w-3" />
          </button>
        </div>
        {!isVideo && (
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[9px] uppercase tracking-wider text-muted-foreground">Enhance</span>
            <button onClick={onUpscale} className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
              <ArrowUpCircle className="h-3 w-3" /> Upscale
            </button>
            <button onClick={onSharpen} className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
              Sharpen
            </button>
            <button onClick={onDeblur} className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
              Deblur
            </button>
            <button onClick={onFace} className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
              Face
            </button>
            <button onClick={onUseAsReference} className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-white/10 hover:text-foreground transition">
              <Layers className="h-3 w-3" /> Use as ref
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export function LiquidSpinner({ large = false }: { large?: boolean }) {
  const size = large ? "h-12 w-12" : "h-4 w-4";
  return (
    <div className={`relative ${size}`}>
      <div className="absolute inset-0 rounded-full border-2 border-white/20" />
      <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-white animate-spin-slow" />
      <div className="absolute inset-1 rounded-full bg-white/10 backdrop-blur-md animate-pulse-glow" />
    </div>
  );
}
