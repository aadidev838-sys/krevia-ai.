import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, X, ImagePlus } from "lucide-react";

type Photo = { id: string; url: string; name: string };

export function PhotoUpload() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const next: Photo[] = [];
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith("image/")) return;
      next.push({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        url: URL.createObjectURL(file),
        name: file.name,
      });
    });
    setPhotos((prev) => [...next, ...prev]);
  };

  const remove = (id: string) => {
    setPhotos((prev) => {
      const target = prev.find((p) => p.id === id);
      if (target) URL.revokeObjectURL(target.url);
      return prev.filter((p) => p.id !== id);
    });
  };

  return (
    <div className="mx-auto w-full max-w-5xl">
      <div className="flex flex-col items-center gap-4">
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => inputRef.current?.click()}
          className="group relative inline-flex items-center gap-3 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-black shadow-[0_0_30px_rgba(255,255,255,0.25)] transition-all hover:shadow-[0_0_50px_rgba(255,255,255,0.55)]"
        >
          <Upload className="h-4 w-4" />
          Upload Photo
        </motion.button>
        <p className="text-xs text-muted-foreground">
          Pick from your gallery — JPG, PNG, WEBP. Multiple files supported.
        </p>
      </div>

      {photos.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass mt-10 flex flex-col items-center justify-center rounded-3xl border-dashed border-white/10 px-6 py-16 text-center"
        >
          <ImagePlus className="mb-3 h-8 w-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">No photos yet. Upload to start your gallery.</p>
        </motion.div>
      ) : (
        <motion.div
          layout
          className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4"
        >
          <AnimatePresence mode="popLayout">
            {photos.map((p) => (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, scale: 0.85, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: -10 }}
                transition={{ type: "spring", stiffness: 260, damping: 22 }}
                className="glass group relative aspect-square overflow-hidden rounded-2xl"
              >
                <img
                  src={p.url}
                  alt={p.name}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <button
                  onClick={() => remove(p.id)}
                  aria-label={`Remove ${p.name}`}
                  className="absolute right-2 top-2 inline-flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur transition-all hover:bg-red-500 hover:scale-110"
                >
                  <X className="h-4 w-4" />
                </button>
                <div className="absolute bottom-2 left-2 right-2 truncate text-[10px] text-white/85 opacity-0 transition-opacity group-hover:opacity-100">
                  {p.name}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}