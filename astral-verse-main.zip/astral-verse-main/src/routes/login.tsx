import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  validateSearch: z.object({
    // Only accept safe internal paths to prevent open-redirect attacks.
    redirect: z
      .string()
      .refine((v) => v.startsWith("/") && !v.startsWith("//") && !v.includes("://"), {
        message: "redirect must be an internal path",
      })
      .optional(),
  }),
  head: () => ({
    meta: [
      { title: "Sign in — krevia-ai" },
      { name: "description", content: "Sign in to krevia-ai to generate AI images and videos." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { user, loading, signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const search = Route.useSearch();
  const redirectTo = search.redirect ?? "/";
  type Status = "idle" | "starting" | "redirecting" | "exchanging" | "success" | "error";
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) {
      setStatus("success");
      navigate({ to: redirectTo });
    }
  }, [user, loading, redirectTo, navigate]);

  const handleGoogle = async () => {
    setErrorMsg(null);
    setStatus("starting");
    try {
      const result = await signInWithGoogle();
      if (result.error) {
        setStatus("error");
        setErrorMsg(result.error);
        toast.error("Sign-in failed", { description: result.error });
        return;
      }
      if (result.redirected) {
        // Browser is navigating away to Google; keep UI in redirect state.
        setStatus("redirecting");
        return;
      }
      // Tokens received in-place — wait for auth listener to set the user.
      setStatus("exchanging");
      toast.success("Signed in with Google");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong";
      setStatus("error");
      setErrorMsg(message);
      toast.error("Sign-in failed", { description: message });
    }
  };

  const busy = status === "starting" || status === "redirecting" || status === "exchanging" || status === "success";

  const buttonLabel =
    status === "starting"
      ? "Opening Google…"
      : status === "redirecting"
        ? "Redirecting to Google…"
        : status === "exchanging"
          ? "Finishing sign-in…"
          : status === "success"
            ? "Signed in — redirecting…"
            : "Continue with Google";

  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 flex min-h-screen items-center justify-center px-4 pt-24">
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
          className="glass-strong w-full max-w-md rounded-3xl p-8 md:p-10"
        >
          <div className="mb-6 flex justify-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-black animate-pulse-glow">
              <Sparkles className="h-5 w-5" />
            </div>
          </div>
          <h1 className="text-center font-display text-3xl font-bold">Continue to krevia-ai</h1>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            Sign in with Google to keep generating. Your prompt will be waiting for you.
          </p>

          <div className="mt-8">
            <button
              type="button"
              onClick={handleGoogle}
              disabled={busy}
              aria-busy={busy}
              className="flex w-full items-center justify-center gap-3 rounded-full bg-white px-6 py-3.5 text-sm font-semibold text-black transition-all hover:scale-[1.02] hover:shadow-[0_0_50px_rgba(255,255,255,0.5)] disabled:cursor-not-allowed disabled:opacity-70 disabled:hover:scale-100 disabled:hover:shadow-none"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <GoogleIcon />}
              <span>{buttonLabel}</span>
            </button>

            <div aria-live="polite" className="mt-4 min-h-[1.5rem] text-center text-xs">
              {status === "starting" && (
                <span className="text-muted-foreground">Preparing secure sign-in…</span>
              )}
              {status === "redirecting" && (
                <span className="text-muted-foreground">A Google window should open. Please complete sign-in.</span>
              )}
              {status === "exchanging" && (
                <span className="text-muted-foreground">Verifying your account…</span>
              )}
              {status === "success" && (
                <span className="inline-flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Signed in successfully
                </span>
              )}
              {status === "error" && errorMsg && (
                <span className="inline-flex items-center gap-1.5 text-red-400">
                  <AlertCircle className="h-3.5 w-3.5" /> {errorMsg}
                </span>
              )}
            </div>
          </div>

          <p className="mt-6 text-center text-[11px] text-muted-foreground">
            By continuing, you agree to our <Link to="/" className="underline-offset-4 hover:underline">Terms & Privacy</Link>.
          </p>
        </motion.div>
      </main>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none">
      <path d="M21 12.23c0-.72-.06-1.24-.2-1.79H12v3.4h5.17c-.1.84-.66 2.11-1.9 2.97l-.01.11 2.78 2.1.2.02A8.73 8.73 0 0 0 21 12.23Z" fill="currentColor"/>
      <path d="M12 21c2.53 0 4.65-.81 6.2-2.2l-2.96-2.24c-.8.54-1.87.9-3.24.9A5.64 5.64 0 0 1 6.7 13.6l-.1.01-2.9 2.18-.03.1A9.45 9.45 0 0 0 12 21Z" fill="currentColor" opacity=".8"/>
      <path d="M6.7 13.6A5.7 5.7 0 0 1 6.37 12c0-.56.12-1.1.32-1.61l-.01-.11L3.75 8.05l-.1.05A9.11 9.11 0 0 0 2.86 12c0 1.43.35 2.79.97 3.9L6.7 13.6Z" fill="currentColor" opacity=".7"/>
      <path d="M12 6.54c1.76 0 2.94.74 3.62 1.37l2.65-2.53C16.64 3.95 14.53 3 12 3a9.41 9.41 0 0 0-8.35 5.1l3.04 2.29A5.64 5.64 0 0 1 12 6.54Z" fill="currentColor" opacity=".9"/>
    </svg>
  );
}
