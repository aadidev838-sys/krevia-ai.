import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions — krevia-ai" },
      { name: "description", content: "Terms and conditions for using krevia-ai's AI image and video generation platform." },
      { property: "og:title", content: "Terms & Conditions — krevia-ai" },
      { property: "og:description", content: "Rules and acceptable use policy for krevia-ai." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 px-4 pt-32 pb-20">
        <article className="glass mx-auto max-w-3xl rounded-3xl p-8 md:p-12">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Legal</p>
          <h1 className="mt-3 font-display text-4xl md:text-5xl font-bold text-gradient">
            Terms &amp; Conditions
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
          </p>

          <div className="mt-10 space-y-8 text-sm leading-relaxed text-muted-foreground">
            <Section title="1. About krevia-ai">
              krevia-ai is a platform that provides AI-powered image and video generation tools.
              By accessing or using the service, you agree to these Terms &amp; Conditions.
            </Section>

            <Section title="2. Acceptable Use">
              You agree not to use krevia-ai to generate, request, upload, or distribute any content that is harmful,
              illegal, or violates these terms. You are solely responsible for the prompts you submit
              and the content generated from your account.
            </Section>

            <Section title="3. Strictly Prohibited Content">
              The following categories of content are <span className="font-semibold text-foreground">strictly prohibited</span> on krevia-ai:
              <ul className="mt-3 list-disc space-y-1.5 pl-6">
                <li>Adult, sexual, or 18+ content of any kind</li>
                <li>Nudity, partial nudity, or sexually suggestive imagery</li>
                <li>Pornographic or fetish content</li>
                <li>Child sexual abuse material (CSAM) — zero tolerance</li>
                <li>Graphic violence, gore, or content glorifying harm</li>
                <li>Hate speech, harassment, or content targeting protected groups</li>
                <li>Illegal activities, weapons creation, or drug-related content</li>
                <li>Deepfakes or non-consensual depictions of real people</li>
                <li>Content infringing on copyright, trademark, or other IP rights</li>
                <li>Misinformation, scams, or content designed to deceive</li>
              </ul>
            </Section>

            <Section title="4. Safe Usage Guidelines">
              Users must follow safe usage guidelines at all times. Our automated systems may refuse,
              filter, or block prompts and outputs that appear to violate these terms. The platform
              reserves the right to refuse any unsafe prompt without explanation.
            </Section>

            <Section title="5. Enforcement">
              Administrators may suspend, restrict, or permanently block any account found to be misusing
              the service. Repeated or severe violations may be reported to relevant authorities where required by law.
            </Section>

            <Section title="6. Responsibility for Generated Content">
              You retain responsibility for any content you generate, download, share, or publish using krevia-ai.
              You agree to indemnify krevia-ai against claims arising from your generated content or its misuse.
            </Section>

            <Section title="7. Service Availability">
              The service is provided "as is" without warranties of any kind. We may modify, suspend, or
              discontinue features at any time without notice.
            </Section>

            <Section title="8. Changes to These Terms">
              We may update these Terms from time to time. Continued use of the platform after changes
              constitutes acceptance of the updated Terms.
            </Section>

            <Section title="9. Contact">
              Questions about these Terms? Reach out via the feedback button on the site.
            </Section>
          </div>
        </article>
      </main>
      <Footer />
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="font-display text-xl font-semibold text-foreground">{title}</h2>
      <div className="mt-2">{children}</div>
    </section>
  );
}