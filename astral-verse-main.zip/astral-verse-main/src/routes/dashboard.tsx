import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { PromptGenerator } from "@/components/PromptGenerator";
import { Download, Copy, Clock, Check, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — krevia-ai" },
      { name: "description", content: "Your krevia-ai creations and generation history." },
      { property: "og:title", content: "Dashboard — krevia-ai" },
      { property: "og:description", content: "Your krevia-ai creations and generation history." },
    ],
  }),
  component: Dashboard,
});

const history = [
  { id: 1, prompt: "A lone astronaut on a glass cliff overlooking a black hole, cinematic", url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600", time: "2m ago" },
  { id: 2, prompt: "Slow-motion ink dropping into water, monochrome, ultra detailed", url: "https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=600", time: "12m ago" },
  { id: 3, prompt: "Brutalist architecture under midnight rain", url: "https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=600", time: "1h ago" },
  { id: 4, prompt: "Aurora borealis reflected on a still glacier lake", url: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=600", time: "3h ago" },
];

function Dashboard() {
  const [copied, setCopied] = useState<number | null>(null);
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: "/login", search: { redirect: "/dashboard" } });
    }
  }, [user, loading, navigate]);

  if (loading || !user) {
    return (
      <div className="relative min-h-screen overflow-hidden">
        <BackgroundFX />
        <Navbar />
        <main className="relative z-10 flex min-h-screen items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </main>
      </div>
    );
  }

  const copy = (id: number, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 mx-auto max-w-7xl px-4 pt-28 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Studio</p>
          <h1 className="mt-2 font-display text-4xl md:text-5xl font-bold text-gradient">Welcome back</h1>
        </motion.div>

        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          {/* Generator */}
          <div>
            <div className="flex justify-center lg:justify-start">
              <PromptGenerator />
            </div>

            <h2 className="mt-12 mb-4 font-display text-xl font-semibold">Recent creations</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {history.map((h, i) => (
                <motion.div
                  key={h.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  className="glass group overflow-hidden rounded-2xl"
                >
                  <div
                    className="aspect-video bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                    style={{ backgroundImage: `url(${h.url})`, filter: "grayscale(100%)" }}
                  />
                  <div className="p-4">
                    <p className="line-clamp-2 text-sm text-muted-foreground">{h.prompt}</p>
                    <div className="mt-3 flex items-center gap-2">
                      <button
                        onClick={() => copy(h.id, h.prompt)}
                        className="flex flex-1 items-center justify-center gap-2 rounded-full border border-white/10 bg-white/5 py-2 text-xs hover:bg-white/10 transition"
                      >
                        {copied === h.id ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                        {copied === h.id ? "Copied" : "Copy prompt"}
                      </button>
                      <a
                        href={h.url}
                        download
                        className="flex flex-1 items-center justify-center gap-2 rounded-full bg-white py-2 text-xs font-semibold text-black hover:shadow-[0_0_30px_rgba(255,255,255,0.4)] transition"
                      >
                        <Download className="h-3.5 w-3.5" />
                        Download
                      </a>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* History panel */}
          <aside className="glass h-fit rounded-3xl p-6 lg:sticky lg:top-28">
            <div className="mb-4 flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-display text-lg font-semibold">History</h3>
            </div>
            <div className="space-y-2">
              {history.map((h) => (
                <button
                  key={h.id}
                  onClick={() => copy(h.id, h.prompt)}
                  className="group w-full rounded-xl border border-transparent bg-white/[0.02] p-3 text-left transition-all hover:border-white/10 hover:bg-white/[0.06]"
                >
                  <p className="line-clamp-2 text-xs text-foreground/90">{h.prompt}</p>
                  <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{h.time}</p>
                </button>
              ))}
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}