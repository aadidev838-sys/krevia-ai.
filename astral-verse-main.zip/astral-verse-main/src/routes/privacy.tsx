import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — krevia-ai" },
      { name: "description", content: "How krevia-ai collects, uses, and protects your data." },
      { property: "og:title", content: "Privacy Policy — krevia-ai" },
      { property: "og:description", content: "How krevia-ai collects, uses, and protects your data." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 px-4 pt-32 pb-20">
        <article className="glass mx-auto max-w-3xl rounded-3xl p-8 md:p-12">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Legal</p>
          <h1 className="mt-3 font-display text-4xl md:text-5xl font-bold text-gradient">
            Privacy Policy
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
          </p>

          <div className="mt-10 space-y-8 text-sm leading-relaxed text-muted-foreground">
            <Section title="1. Data We Collect">
              When you use krevia-ai we may collect:
              <ul className="mt-3 list-disc space-y-1.5 pl-6">
                <li>Account information from your Google sign-in (name, email, profile photo)</li>
                <li>Prompts, negative prompts, and generation settings you submit</li>
                <li>Reference images you upload for image-to-image editing</li>
                <li>Generated images and videos created from your prompts</li>
                <li>Basic usage analytics (page views, feature usage, error logs)</li>
              </ul>
            </Section>

            <Section title="2. Authentication via Google">
              We use Google OAuth as our sole sign-in method. Google shares only the basic profile
              information you authorize. We never receive or store your Google password.
            </Section>

            <Section title="3. How We Use Your Data">
              Your data is used solely to operate and improve the service: routing your prompts to AI
              models, displaying your generation history, securing your account, and preventing abuse.
              <span className="font-semibold text-foreground"> We do not sell your personal data, and we do not misuse it.</span>
            </Section>

            <Section title="4. Secure Storage">
              User data is stored in encrypted databases hosted on trusted cloud infrastructure.
              Access is restricted by role-based permissions and protected by industry-standard
              authentication and transport encryption (HTTPS/TLS).
            </Section>

            <Section title="5. Cookies">
              We use essential cookies and local storage to keep you signed in, remember your
              preferences, and store generation history locally on your device. We do not use
              advertising or cross-site tracking cookies.
            </Section>

            <Section title="6. Third-Party AI Providers">
              Prompts and reference images are sent to third-party AI providers (such as Google's
              Gemini models and other generation APIs) to produce your output. These providers
              process the data according to their own privacy policies. Do not include sensitive
              personal information in your prompts.
            </Section>

            <Section title="7. Data Protection">
              We take reasonable technical and organizational measures to protect your data against
              unauthorized access, alteration, disclosure, or destruction. No system is 100% secure,
              but we work to maintain industry best practices.
            </Section>

            <Section title="8. Your Rights">
              You can request deletion of your account and associated data at any time by contacting us.
              You may also clear your local generation history directly from the in-app history sidebar.
            </Section>

            <Section title="9. Contact">
              For privacy questions or data deletion requests, contact us via the feedback button
              on the site or reach out to our team through the official channels listed in the footer.
            </Section>
          </div>
        </article>
      </main>
      <Footer />
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="font-display text-xl font-semibold text-foreground">{title}</h2>
      <div className="mt-2">{children}</div>
    </section>
  );
}