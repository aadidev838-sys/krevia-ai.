import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { FeedbackButton } from "@/components/FeedbackButton";
import { HistorySidebar } from "@/components/HistorySidebar";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="glass max-w-md rounded-3xl p-10 text-center">
        <h1 className="font-display text-7xl font-bold text-gradient">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Lost in the void</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          This page drifted somewhere we can't reach.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center justify-center rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground glow-hover"
        >
          Return home
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "krevia-ai — AI Images & Videos From One Prompt" },
      { name: "description", content: "Generate stunning AI images and videos from a single prompt. Premium liquid-glass interface, lightning-fast renders, HD quality." },
      { name: "author", content: "krevia-ai" },
      { property: "og:title", content: "krevia-ai — AI Images & Videos From One Prompt" },
      { property: "og:description", content: "Generate stunning AI images and videos from a single prompt. Premium liquid-glass interface, lightning-fast renders, HD quality." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@krevia-ai" },
      { name: "twitter:title", content: "krevia-ai — AI Images & Videos From One Prompt" },
      { name: "twitter:description", content: "Generate stunning AI images and videos from a single prompt. Premium liquid-glass interface, lightning-fast renders, HD quality." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/b5ad0af0-eab5-449f-a7ac-49712f1d1e9d" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/b5ad0af0-eab5-449f-a7ac-49712f1d1e9d" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <Outlet />
      <HistorySidebar />
      <FeedbackButton />
      <Toaster />
    </AuthProvider>
  );
}
