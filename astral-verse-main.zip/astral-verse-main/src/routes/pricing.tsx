import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — krevia-ai" },
      { name: "description", content: "Simple, transparent pricing for AI image and video generation." },
      { property: "og:title", content: "Pricing — krevia-ai" },
      { property: "og:description", content: "Simple, transparent pricing for AI image and video generation." },
    ],
  }),
  component: PricingPage,
});

const plans = [
  {
    name: "Free",
    price: "$0",
    tagline: "For curious minds.",
    features: ["20 generations / month", "HD images", "Watermarked videos", "Community support"],
    cta: "Start free",
  },
  {
    name: "Pro",
    price: "$19",
    tagline: "For serious creators.",
    features: ["Unlimited generations", "4K images & 1080p video", "No watermark", "Priority queue", "Commercial license"],
    cta: "Go Pro",
    highlight: true,
  },
  {
    name: "Studio",
    price: "$49",
    tagline: "For teams.",
    features: ["Everything in Pro", "Team workspace", "API access", "Dedicated support"],
    cta: "Contact us",
  },
];

function PricingPage() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 px-4 pt-32 pb-20">
        <div className="mx-auto max-w-6xl text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Pricing</p>
          <h1 className="mt-3 font-display text-5xl md:text-6xl font-bold text-gradient">
            Pay for what you create
          </h1>
          <p className="mt-4 text-muted-foreground">No hidden fees. Cancel any time.</p>
        </div>

        <div className="mx-auto mt-14 grid max-w-6xl gap-5 md:grid-cols-3">
          {plans.map((p, i) => (
            <motion.div
              key={p.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`glass relative rounded-3xl p-8 transition-all hover:-translate-y-1 ${
                p.highlight ? "border-white/30 bg-white/[0.08] shadow-[0_0_60px_rgba(255,255,255,0.1)]" : ""
              }`}
            >
              {p.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-white px-3 py-1 text-xs font-semibold text-black">
                  Most popular
                </span>
              )}
              <h3 className="font-display text-2xl font-bold">{p.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{p.tagline}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold">{p.price}</span>
                <span className="text-sm text-muted-foreground">/month</span>
              </div>
              <ul className="mt-6 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Check className="h-4 w-4 text-white" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                className={`mt-8 w-full rounded-full py-3 text-sm font-semibold transition-all ${
                  p.highlight
                    ? "bg-white text-black hover:shadow-[0_0_40px_rgba(255,255,255,0.5)]"
                    : "border border-white/15 hover:bg-white/5"
                }`}
              >
                {p.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}