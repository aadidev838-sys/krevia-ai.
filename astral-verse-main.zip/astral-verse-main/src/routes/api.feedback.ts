import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/feedback")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { message, email } = (await request.json()) as {
            message?: string;
            email?: string;
          };

          const trimmed = (message ?? "").trim();
          if (!trimmed || trimmed.length < 2 || trimmed.length > 5000) {
            return Response.json(
              { error: "Message must be between 2 and 5000 characters." },
              { status: 400 },
            );
          }

          const RESEND_API_KEY = process.env.RESEND_API_KEY;
          if (!RESEND_API_KEY) {
            return Response.json(
              { error: "Email service is not configured." },
              { status: 500 },
            );
          }

          const safeEmail =
            email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : null;

          const escape = (s: string) =>
            s
              .replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;");

          const html = `
            <div style="font-family:Inter,Arial,sans-serif;background:#0b0b12;padding:24px;color:#e5e7eb;">
              <h2 style="margin:0 0 12px;color:#fff;">New Feedback — krevia-ai</h2>
              ${safeEmail ? `<p style="margin:0 0 8px;color:#9ca3af;">From: <strong style="color:#fff;">${escape(safeEmail)}</strong></p>` : ""}
              <div style="margin-top:12px;padding:16px;border-radius:12px;background:#15151f;border:1px solid #27272f;white-space:pre-wrap;line-height:1.5;">
                ${escape(trimmed)}
              </div>
            </div>
          `;

          const res = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${RESEND_API_KEY}`,
            },
              body: JSON.stringify({
                from: "krevia-ai Feedback <onboarding@resend.dev>",
                to: ["aadidev838@gmail.com"],
                subject: safeEmail
                  ? `New feedback from ${safeEmail}`
                  : "New feedback from krevia-ai",
                html,
                reply_to: safeEmail ?? undefined,
              }),
          });

          if (!res.ok) {
            const text = await res.text();
            console.error("Resend error:", res.status, text);
            return Response.json(
              { error: "Failed to send feedback. Please try again." },
              { status: 502 },
            );
          }

          return Response.json({ ok: true });
        } catch (err) {
          console.error("Feedback handler error:", err);
          return Response.json(
            { error: "Unexpected server error." },
            { status: 500 },
          );
        }
      },
    },
  },
});
