import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Image as ImageIcon, Video, Zap, Sparkles, Wand2, Box, TrendingUp } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { BackgroundFX } from "@/components/BackgroundFX";
import { PromptGenerator } from "@/components/PromptGenerator";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "krevia-ai — Create AI Images & Videos From One Prompt" },
      { name: "description", content: "Premium liquid-glass AI generator. One prompt, stunning images and videos in seconds." },
      { property: "og:title", content: "krevia-ai — AI Images & Videos From One Prompt" },
      { property: "og:description", content: "Premium liquid-glass AI generator. One prompt, stunning images and videos in seconds." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundFX />
      <Navbar />

      <main className="relative z-10 px-4 pt-32 pb-20">
        {/* Hero */}
        <section className="mx-auto flex max-w-6xl flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-muted-foreground"
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
            New — Video generation is live
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-5xl md:text-7xl font-bold leading-[1.05] text-gradient"
          >
            Create AI Images & Videos
            <br />
            From One Prompt
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 max-w-xl text-base md:text-lg text-muted-foreground"
          >
            A liquid-glass studio for high-fidelity visuals. Type. Generate. Download.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="glass mt-6 inline-flex items-center gap-3 rounded-full px-4 py-2 text-sm text-muted-foreground"
          >
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-black font-semibold">
              G
            </span>
            Google OAuth login UI ready
          </motion.div>

          {/* Floating glass icons */}
          <FloatingIcons />

          <div id="generator" className="mt-12 w-full flex justify-center">
            <PromptGenerator />
          </div>
        </section>

        {/* Features */}
        <section id="features" className="mx-auto mt-32 max-w-6xl">
          <SectionTitle eyebrow="Features" title="Built for AI generation" />
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="glass group relative overflow-hidden rounded-2xl p-6 transition-all hover:-translate-y-2 hover:bg-white/[0.06]"
              >
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/5">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
                <div className="absolute -bottom-12 -right-12 h-32 w-32 rounded-full bg-white/5 blur-2xl opacity-0 transition-opacity group-hover:opacity-100" />
              </motion.div>
            ))}
          </div>
        </section>

        {/* Demo Gallery */}
        <section id="gallery" className="mx-auto mt-32 max-w-6xl">
          <SectionTitle eyebrow="Gallery" title="Made with krevia-ai" />
          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
            {gallery.map((g, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className={`glass group relative overflow-hidden rounded-2xl ${g.tall ? "row-span-2 aspect-[3/5]" : "aspect-square"}`}
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                  style={{ backgroundImage: `url(${g.url})`, filter: "grayscale(100%) contrast(1.1)" }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-black/0" />
                <div className="absolute bottom-3 left-3 right-3 text-xs text-white/80 opacity-0 transition-opacity group-hover:opacity-100">
                  {g.label}
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Popular styles */}
        <section id="styles" className="mx-auto mt-32 max-w-6xl">
          <SectionTitle eyebrow="Styles" title="Popular looks" />
          <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {popularStyles.map((s, i) => (
              <motion.div
                key={s.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.45, delay: i * 0.04 }}
                className="glass group relative aspect-[4/5] overflow-hidden rounded-2xl"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                  style={{ backgroundImage: `url(${s.url})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <p className="text-[10px] uppercase tracking-wider text-white/60">Style</p>
                  <p className="font-display text-lg font-semibold">{s.name}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Trending prompts */}
        <section id="trending" className="mx-auto mt-32 max-w-6xl">
          <SectionTitle eyebrow="Trending" title="What people are creating" />
          <div className="mt-12 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {trendingPrompts.map((t, i) => (
              <motion.button
                key={t}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.4, delay: i * 0.04 }}
                onClick={() => {
                  document.getElementById("generator")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="glass group flex items-start gap-3 rounded-2xl p-4 text-left transition hover:-translate-y-1 hover:bg-white/[0.06]"
              >
                <span className="mt-0.5 inline-flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/5">
                  <TrendingUp className="h-4 w-4 text-white/70" />
                </span>
                <span className="text-sm text-muted-foreground group-hover:text-foreground transition">{t}</span>
              </motion.button>
            ))}
          </div>
        </section>

        <section id="pricing" className="mx-auto mt-32 max-w-5xl">
          <SectionTitle eyebrow="Pricing" title="Simple, weightless plans" />
          <div className="mt-12 grid gap-5 md:grid-cols-2">
            <PricingCard
              name="Free"
              price="$0"
              tagline="For curious minds."
              features={["20 generations / month", "HD images", "Watermarked videos", "Community support"]}
              cta="Start free"
            />
            <PricingCard
              name="Pro"
              price="$19"
              tagline="For serious creators."
              features={["Unlimited generations", "4K images & 1080p video", "No watermark", "Priority queue", "Commercial license"]}
              cta="Go Pro"
              highlight
            />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

function SectionTitle({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="text-center">
      <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">{eyebrow}</p>
      <h2 className="mt-3 font-display text-4xl md:text-5xl font-bold text-gradient">{title}</h2>
    </div>
  );
}

function FloatingIcons() {
  const icons = [
    { Icon: ImageIcon, x: "5%", y: "10%", delay: "0s" },
    { Icon: Video, x: "90%", y: "20%", delay: "1s" },
    { Icon: Sparkles, x: "12%", y: "70%", delay: "2s" },
    { Icon: Box, x: "88%", y: "75%", delay: "0.5s" },
  ];
  return (
    <div className="pointer-events-none absolute inset-0 hidden md:block">
      {icons.map(({ Icon, x, y, delay }, i) => (
        <div
          key={i}
          className="glass absolute flex h-12 w-12 items-center justify-center rounded-2xl animate-float-slow"
          style={{ left: x, top: y, animationDelay: delay }}
        >
          <Icon className="h-5 w-5 text-white/70" />
        </div>
      ))}
    </div>
  );
}

function PricingCard({
  name, price, tagline, features, cta, highlight,
}: {
  name: string; price: string; tagline: string; features: string[]; cta: string; highlight?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className={`glass relative rounded-3xl p-8 transition-all hover:-translate-y-1 ${
        highlight ? "border-white/30 bg-white/[0.08] shadow-[0_0_60px_rgba(255,255,255,0.1)]" : ""
      }`}
    >
      {highlight && (
        <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-white px-3 py-1 text-xs font-semibold text-black">
          Most popular
        </span>
      )}
      <h3 className="font-display text-2xl font-bold">{name}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{tagline}</p>
      <div className="mt-6 flex items-baseline gap-1">
        <span className="font-display text-5xl font-bold">{price}</span>
        <span className="text-sm text-muted-foreground">/month</span>
      </div>
      <ul className="mt-6 space-y-3">
        {features.map((f) => (
          <li key={f} className="flex items-center gap-3 text-sm text-muted-foreground">
            <span className="flex h-5 w-5 items-center justify-center rounded-full border border-white/15 bg-white/5">
              <span className="h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            {f}
          </li>
        ))}
      </ul>
      <button
        className={`mt-8 w-full rounded-full py-3 text-sm font-semibold transition-all ${
          highlight
            ? "bg-white text-black hover:shadow-[0_0_40px_rgba(255,255,255,0.5)]"
            : "border border-white/15 hover:bg-white/5"
        }`}
      >
        {cta}
      </button>
    </motion.div>
  );
}

const features = [
  { icon: ImageIcon, title: "AI Images", desc: "From sketch to photoreal. Any style, any subject." },
  { icon: Video, title: "AI Videos", desc: "Cinematic motion. Generate clips from a single line." },
  { icon: Zap, title: "Lightning Fast", desc: "Optimized pipeline. Most renders under 8 seconds." },
  { icon: Wand2, title: "HD Quality", desc: "4K stills and crisp 1080p video, ready to ship." },
];

const gallery = [
  { url: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800", label: "Cosmic drift", tall: true },
  { url: "https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=800", label: "Liquid form" },
  { url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800", label: "Galaxy ink" },
  { url: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800", label: "Deep field" },
  { url: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800", label: "Monochrome" },
  { url: "https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=800", label: "Architecture" },
  { url: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=800", label: "Aurora", tall: true },
];

const popularStyles: { name: string; url: string }[] = [
  { name: "Realistic", url: "https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=600" },
  { name: "Anime", url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600" },
  { name: "3D Render", url: "https://images.unsplash.com/photo-1633412802994-5c058f151b66?w=600" },
  { name: "Cinematic", url: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=600" },
  { name: "Digital Art", url: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?w=600" },
  { name: "Portrait", url: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600" },
  { name: "Fantasy", url: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=600" },
  { name: "Cartoon", url: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=600" },
];

const trendingPrompts: string[] = [
  "A lone astronaut on a glass cliff overlooking a black hole, cinematic",
  "Neon-lit cyberpunk alley with rain reflections, ultra detailed",
  "Mythical phoenix rising from molten gold, dramatic lighting",
  "Tiny isometric island floating in pastel clouds, 3D render",
  "Origami fox in a moonlit bamboo forest, depth of field",
  "Cosmic jellyfish drifting through a nebula, ethereal",
];
