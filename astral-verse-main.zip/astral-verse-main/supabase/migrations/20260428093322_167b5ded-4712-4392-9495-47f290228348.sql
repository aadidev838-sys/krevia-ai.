-- Revoke EXECUTE from PUBLIC, anon, and authenticated on SECURITY DEFINER functions.
-- These functions are only meant to be called by triggers (with table owner privileges),
-- never directly via the API.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;